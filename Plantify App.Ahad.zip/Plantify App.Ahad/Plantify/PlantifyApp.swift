//
//  PlantifyApp.swift
//  Plantify
//
//  Created by Ahad on 14/08/1445 AH.
//

import SwiftUI
import SwiftData

@main
struct PlantifyApp: App {
  

    var body: some Scene {
        WindowGroup {
            CombinedContentView()
        }
        .modelContainer(for : [modelItems.self])
    }
}
