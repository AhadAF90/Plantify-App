//
//  modelContiner.swift
//  Plantify
//
//  Created by Ahad on 15/08/1445 AH.
//


import Foundation
import SwiftData

var sharedModelContainer: ModelContainer = {
    let schema = Schema([
        modelItems.self,
    ])
    let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

    do {
        return try ModelContainer(for: schema, configurations: [modelConfiguration])
    } catch {
        fatalError("Could not create ModelContainer: \(error)")
    }
}()
