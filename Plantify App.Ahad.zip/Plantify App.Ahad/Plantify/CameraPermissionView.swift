//
//  CameraPermissionView.swift
//  Plantify
//
//  Created by Rimah on 15/08/1445 AH.
//

import SwiftUI
import AVFoundation // Needed for camera access

// Second Page: Camera Permission Request
struct CameraPermissionView: View {
    @State private var showCamera = false
    
    var body: some View {
        VStack {
            if showCamera {
                // Camera view goes here
            } else {
                // Permission request goes here
                VStack {
                    Text("\"Plantify\" Would Like to Access the Camera")
                    Text("This will let you take photos")
                    Button("Don't Allow") {
                        // Handle Don't Allow
                    }
                    Button("OK") {
                        // Handle OK
                        self.requestCameraAccess()
                    }
                }
            }
        }
    }
    
    private func requestCameraAccess() {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            if granted {
                // Update the UI to show the camera
                DispatchQueue.main.async {
                    self.showCamera = true
                }
            } else {
                // Handle the user not granting permission
            }
        }
    }
}
#Preview {
    CameraPermissionView ()
}
