//
//  PlantInfoSheet.swift
//  Plantify
//
//  Created by Ahad on 15/08/1445 AH.
//


import SwiftUI
import SwiftData

struct PlantInfoSheet: View {
        var QuoteConfig: modelItems
        @State private var showingCamera = false
        @State private var showingConfirmation = false
        @State private var image: Image?
        @State private var photoDate: Date?
        @State private var text: String = ""
        @State private var showingFeedback = false // State to control the feedback view presentation
        
        @Query(sort: [SortDescriptor(\modelItems.createdDate, order: .reverse)], animation: .default)
        private var items: [modelItems]
        
        
        @Environment(\.dismiss) private var dismiss
        @Environment(\.modelContext) private var context
        
        @Bindable var plants: modelItems
        
        @State var images: [modelItems]
        
        @State private var showAlert = false
        
        private func deletePlant() {
            context.delete(plants)
            dismiss()
        }
        
        @Query var itemss: [modelItems]
        @Environment(\.scenePhase) private var scenePhase
        
        @State private var isShowingItemSheet = false
        @State private var inputText = ""
        @State private var selectedOption = 0
        let options = ["Today", "Next Week", "Overdue"]
        let customColor = Color(UIColor(red: 0/255, green: 70/255, blue: 50/255, alpha: 1))
       
    var body: some View {
        NavigationStack {
            VStack {
                Divider()
                LazyHGrid(rows: [GridItem(.flexible())]) {
                    let details: [String] = [
                        "\(plants.plantype)", // Replace 'plantType' with actual property name
                        "\(plants.potsize)",   // Replace 'potSize' with actual property name
                        "\(plants.Light)",     // Replace 'light' with actual property name
                        "\(plants.watering)/week" // Replace 'watering' with actual property name
                    ]
                    ForEach(details, id: \.self) { detail in
                        Text(detail)
                            .font(.system(size: 16))
                            .frame(width: 90, height: 30, alignment: .center)
                            .background(Color(red: 252/255, green: 250/255, blue: 247/255, opacity: 1))
                            .cornerRadius(8)
                    }
                }
                VStack {
                                        Text("Advice")
                                            .font(.system(size: 20))
                                            .font(.headline)
                                            .fontWeight(.bold)
                                            .padding(.trailing,290)

                                        Text("Ensure sufficient indirect light and adjust watering frequency.")
                                            .multilineTextAlignment(.center) // Align the text to the center
                                            .font(.system(size: 12))
                                            .frame(width: 380, height: 52)
                                            .background(Color.gray.opacity(0.2))
                                            .cornerRadius(8)

                                        Text("Allow top inch of soil to dry between waterings and adjust frequency based on light conditions.")
                                            .multilineTextAlignment(.center) // Align the text to the center
                                            .font(.system(size: 12))
                                            .frame(width: 380, height: 52)
                                            .background(Color.gray.opacity(0.2))
                                            .cornerRadius(8)
                                    }
                .padding(.bottom, 120)

                VStack {
                    HStack(spacing: 200) {
                        Text("Photo Gallery")
                            .font(.system(size: 20))
                            .fontWeight(.bold)
                        
                        Button(action: {
                            self.showingCamera = true
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 23))
                                .foregroundColor(customColor)
                        }
                    }
                    .padding(.bottom, 120)
                    
                    // Display the captured image
                    if let image = image {
                        image
                            .resizable()
                            .scaledToFit()
                    } else {
                        VStack(spacing: 15) {
                            Image(systemName: "camera.fill")
                                .font(.system(size: 32))
                                .foregroundColor(Color(red: 219 / 255, green: 139 / 255, blue: 0 / 255))
                            
                            HStack { // "Tap" and "Plus" button and "to add one"
                                Text("Tap")
                                Button(action: {
                                    
                                    self.showingCamera = true
                                }) {
                                    Image(systemName: "plus")
                                        .font(.system(size: 17))
                                        .foregroundColor(Color(red: 0 / 255, green: 70 / 255, blue: 50 / 255))
                                }
                                Text("to add one")
                            }
                            
                            Text("Tap the + to add a photo of your plant.")
                                .font(.system(size: 12))
                                .foregroundColor(Color.gray)
                                .multilineTextAlignment(.center)
                        }
                    }
                }
                .padding(.bottom, 120)
                
                Spacer()
            }
            .navigationTitle(plants.text)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Delete") {
                        showAlert = true
                    }
                    .foregroundColor(customColor)
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Delete \(plants.text)?"),
                    message: Text("Are you sure you want to delete \(plants.text)? This action cannot be undone."),
                    primaryButton: .destructive(Text("Delete")) {
                        deletePlant()
                    },
                    secondaryButton: .cancel()
                )
            }
            .sheet(isPresented: $showingCamera) {
                CameraView(isShown: $showingCamera, image: $image) {
                    // No additional actions needed here since feedback view is removed
                }
            }
        }
    }
}

            struct PlantCell : View {
                
                let Plant : modelItems
                var body: some View{
                    HStack{
                        
                        Text(Plant.name)
                        Spacer()
                        
                    }
                    
                }
            }


