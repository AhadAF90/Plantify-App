//
//  PlantInfo.swift
//  Plantify
//
//  Created by Rimah on 15/08/1445 AH.
//
// هذي صفحة الايديت 
import SwiftUI

struct PlantInfoSheet: View {
    
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Bindable var plants: modelItems
    @State private var showAlert = false // State variable to control the alert
    
    // Function to delete the plant
    private func deletePlant() {
        context.delete(plants)
        dismiss()
    }
    
    var body: some View {
        NavigationStack {
            let details: [String] = [
                "\(plants.plantype)",
                "\(plants.potsize)",
                "\(plants.Light)",
                "\(plants.watering)/week"
            ]
            VStack {
                Divider()
                VStack{
                    
                    HStack(alignment: .top) {
                        LazyHGrid(rows: [GridItem(.flexible())], spacing: 16) {
                            ForEach(details, id: \.self) { detail in
                                Text(detail)
                                    .font(.system(size: 16))
                                    .frame(minWidth: 0, minHeight: 0)
                                    .padding(4)
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(8)
                            }
                        }
                        .padding(.vertical)
                        .padding(.top)
                        
                    }
                    VStack(alignment: .leading){
                        Text("Advice")
                            .font(.headline)
                            .padding(.leading) // Add padding to align with rectangles
                        
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 350, height: 70)
                            .padding()
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 350, height: 70)
                            .padding()
                    }
                    
                    HStack{
                        Text("Photo gallery")
                            .font(.headline)
                            .padding()
                        Spacer()
                        Button(action: {
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 15))
                                .font(.title)
                                .padding()
                        }
                    }
                    
                    
                }
                // Spacer to push the Divider up the page
                Spacer()
                    .toolbar {
                        
                        ToolbarItem(placement: .principal) {
                            Text("\(plants.name)")
                                .font(.headline)
                        }
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("Delete") {
                                showAlert = true
                            }
                            .foregroundColor(.red)
                        }
                    }
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Delete \(plants.name)?"),
                message: Text("Are you sure you want to delete \(plants.name)? This action cannot be undone."),
                primaryButton: .destructive(Text("Delete")) {
                    deletePlant()
                },
                secondaryButton: .cancel()
            )
        }
    }
}
